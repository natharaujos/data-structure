/* 
  Trabalho de Estrutura de Dados 
  Copyright 2021 by Igor Freire de Morais, Nathan Araújo Silva, Mateus Peternelli
  É responsável pelo struct.
*/

#include <iostream>
#include <cstring>
#include <fstream>
#include <cstdlib>

using namespace std;


struct pacote {
    unsigned posicao;
    char modelo[30];
    char cache[15];
    unsigned tdp;

};

float stof2(string texto) {
    return atof(texto.c_str());
}

unsigned stoul2(string texto) {
    return atol(texto.c_str());
}
