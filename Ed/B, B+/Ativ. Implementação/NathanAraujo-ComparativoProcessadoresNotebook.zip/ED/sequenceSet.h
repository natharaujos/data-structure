/* 
  Trabalho de Estrutura de Dados 
  Copyright 2021 by Igor Freire de Morais, Nathan Araújo Silva, Mateus Peternelli
  É responsável por ordenador o que tem no arquivo.
*/

#include <iostream>
#include <cstring>
#include <fstream>
#include <cstdlib>
#include "lerArqCSV.h"

using namespace std;

class Noh{
    friend class Grupos;

private:
    pacote mDados;
    unsigned mPosicao;
    Noh *mPtProximo;
    Noh *mPtAnterior;

public:
    Noh(pacote mDados);
    ~Noh();
    Noh *RetornaProximo() { return mPtProximo; }
    Noh *RetornaAnterior() { return mPtAnterior; }
    void RecebeProximo(Noh *mPtProximo) { this->mPtProximo = mPtProximo; }
    void RecebeAnterior(Noh *mPtAnterior) { this->mPtAnterior = mPtAnterior; }
    pacote RetornaDados() { return mDados; }
    void RecebePosicao(unsigned mPosicao) { this->mPosicao = mPosicao; }
    unsigned RetornaPosicao() { return mPosicao; }
};

Noh::Noh(pacote mDados)
{
    this->mDados = mDados;
    this->mPtProximo = NULL;
    this->mPtAnterior = NULL;
    this->mPosicao = 0;
}

Noh::~Noh() {}

//classe que fara as operaçoes dentro dos grupos do senquence set

class Grupos
{
private:
    Noh *mPtInicio;
    Noh *mPtMeio;
    Noh *mPtFim;
    Grupos *mPtProxSeq;
    Grupos *mPtAnteSeq;
    unsigned mTam;
    unsigned mCapacidade;
    unsigned mGrupo;

public:
    Grupos(unsigned mCapacidade, unsigned mGrupo);
    ~Grupos();

    unsigned RetornaGrupoID() { return mGrupo; }

    Grupos *RetornaProximo() { return mPtProxSeq; }
    void RecebeProximo(Grupos *mPtProxSeq) { this->mPtProxSeq = mPtProxSeq; }
    Grupos *RetornaAnterior() { return mPtAnteSeq; }
    void RecebeAnterior(Grupos *mPtAnteSeq) { this->mPtAnteSeq = mPtAnteSeq; }

    //inserção dos elementos de acordo com a ordenação
    void InsereGrupo(pacote dado);
    void InsereInicio(pacote dado);
    void InsereFim(pacote dado);
    void InsereMeio(unsigned posicao, pacote dado);
    void InsereVazia(pacote dado);

    //ordenação para elementos com id modelo
    unsigned Ordena(pacote dado);

    pacote RetiraInicio();
    pacote RetiraFim();

    //inpressao dos elementos dos grupos e os grupos
    void ImprimeGrupo();
    void percorreGrupo();

    void RecebeDadoMeio();
    int RetornaPosicaoMeio()
    {
        RecebeDadoMeio();
        return mPtMeio->RetornaPosicao();
    }
    pacote RetornaMeio()
    {
        RecebeDadoMeio();
        return mPtMeio->RetornaDados();
    }

    unsigned RetornaTamanho() { return mTam; }

    pacote RetornaMaior() { return mPtFim->RetornaDados(); }
    pacote RetornaMenor() { return mPtInicio->RetornaDados(); }
    bool GrupoVazio() { return mTam == 0; }
    bool GrupoCheio() { return mTam == mCapacidade; }
};

Grupos::Grupos(unsigned mCapacidade, unsigned mGrupo)
{
    mPtInicio = NULL;
    mPtFim = NULL;
    mPtProxSeq = NULL;
    mPtAnteSeq = NULL;
    mPtMeio = NULL;
    mTam = 0;
    this->mGrupo = mGrupo;
    this->mCapacidade = mCapacidade;
}

Grupos::~Grupos(){
    FILE *myFile;
    myFile = fopen("data.csv", "a");
    if (myFile == NULL){
    cout << "ERRO! O arquivo não foi aberto!\n";
    }
    while (not GrupoVazio()){
        fprintf (myFile, RetiraInicio().modelo ,", ", "\n");
		cout << endl;
    }
    cout << endl;
}

void Grupos::RecebeDadoMeio()
{
    mPtMeio = mPtInicio;
    for (unsigned i = 0; i < mTam / 2; i++)
    {
        mPtMeio = mPtMeio->RetornaProximo();
        mPtMeio->RecebePosicao(i + 1);
    }
}

//principal função é de direcionar onde sera incerido dado
void Grupos::InsereGrupo(pacote dado)
{
    unsigned posicao;
    if (GrupoVazio())
    {
        InsereVazia(dado);
    }
    else
    {
        //saber qual funçao inserir o dado tem que ir
        posicao = Ordena(dado);
        if (posicao == 0)
        {
            InsereInicio(dado);
        }
        else if (posicao == mTam)
        {
            InsereFim(dado);
        }
        else
        {
            InsereMeio(posicao, dado);
        }
    }
}

//retornar a posicao para saber em que espaço do grupo deve ser colocado o id modelo
unsigned Grupos::Ordena(pacote dado)
{
    Noh *novo;
    novo = mPtInicio;
    unsigned posicao = 0;
    for (unsigned i = 0; i < mTam; i++)
    {
        if (strcmp(dado.modelo, novo->RetornaDados().modelo) == -1)
        {
            return posicao;
        }
        else
        {
            novo = novo->RetornaProximo();
            posicao++;
        }
    }
    return mTam;
}

//inserção em grupo vazio
void Grupos::InsereVazia(pacote dado)
{
    mPtInicio = new Noh(dado);
    mPtFim = mPtInicio;
    mTam++;
}

//inserir no inicio do grupo
void Grupos::InsereInicio(pacote dado)
{
    Noh *novo;
    novo = new Noh(dado);
    mPtInicio->RecebeAnterior(novo);
    novo->RecebeProximo(mPtInicio);
    mPtInicio = novo;
    mTam++;
}

//inserir no fim do grupo
void Grupos::InsereFim(pacote dado)
{
    Noh *novo;
    novo = new Noh(dado);
    mPtFim->RecebeProximo(novo);
    novo->RecebeAnterior(mPtFim);
    mPtFim = novo;
    mTam++;
}

//inserir em uma posicao sem ser inicio ou fim
void Grupos::InsereMeio(unsigned posicao, pacote dado)
{
    Noh *novo;
    novo = new Noh(dado);
    Noh *mPtProximo;
    mPtProximo = mPtInicio;
    Noh *mPtAnterior;
    for (unsigned i = 0; i < mTam; i++)
    {
        mPtAnterior = mPtProximo->RetornaAnterior();

        if (posicao == i)
        {
            if (mPtAnterior != NULL)
            {
                mPtAnterior->RecebeProximo(novo);
            }
            novo->RecebeAnterior(mPtAnterior);

            if (mPtProximo != NULL)
            {
                mPtProximo->RecebeAnterior(novo);
            }
            novo->RecebeProximo(mPtProximo);
            i = mTam;
        }
        mPtProximo = mPtProximo->RetornaProximo();
    }
    mTam++;
}

pacote Grupos::RetiraInicio()
{
    pacote dado;
    Noh *aux;
    aux = mPtInicio;
    mPtInicio = aux->RetornaProximo();
    dado = aux->RetornaDados();
    mTam--;
    delete aux;
    return dado;
}

pacote Grupos::RetiraFim()
{
    pacote dado;
    Noh *aux;
    aux = mPtFim;
    mPtFim = aux->RetornaAnterior();
    dado = aux->RetornaDados();
    mPtFim->RecebeProximo(NULL);
    mTam--;
    delete aux;
    return dado;
}


//imprime elementos dentro dos grupos
void Grupos::ImprimeGrupo(){
    Noh *novo;
    novo = mPtInicio;
    FILE *myFile;
    myFile = fopen("data.csv", "a");
    if (myFile == NULL){
    cout << "ERRO! O arquivo não foi aberto!\n";
    }
    cout << "\nTamanho:" << mTam << " GRUPO [" << mGrupo << "]: ";

    while (novo != NULL)
    {
        fprintf (myFile, "%s %s %d %s", novo->RetornaDados().modelo ,", ", novo->RetornaDados().posicao , "\n");
        cout << novo->RetornaDados().modelo << "," << novo->RetornaDados().posicao << " ";
        novo = novo->RetornaProximo();
    }
    cout << endl;
}

//Essa classe tem como principal funçao encontra o grupo que
//o dado modelo sera inserido
class SeqSets
{
private:
    Grupos *mPtInicio;
    Grupos *mPtFim;
    Grupos *mPtProxGrupoVazio;
    unsigned mTam;
    unsigned mUsando;
    unsigned mGrupo;
    unsigned mCapacidade;

public:
    SeqSets();
    ~SeqSets();

    //funçao que busca qual grupo o elemento sera inserido
    Grupos *BuscaGruposInsercao(pacote dado);
    Grupos *BuscaGruposRemocao(pacote dado);

    //criaçao de grupos
    void CriarGrupoProx(Grupos *mPtAnterior);
    void CriarGrupoAnte(Grupos *mPtProximo);
    void CriarGrupo();

    //destrutor
    void DeletarGrupo();

    void Imprimir();

    bool SeqSetVazia() { return mTam == 0; }
    bool SeqSetUsandoVazia() { return mUsando == 0; }

    //dado inserido pelo usuario
    void InsereDado();
    //derecionar em qual grupo inserir
    void InsereDadoPorParametro(pacote dado);
};

SeqSets::SeqSets()
{
    mTam = 0;
    mUsando = 0;
    mGrupo = 0;
    mPtInicio = NULL;
    mPtFim = NULL;
    mPtProxGrupoVazio = NULL;
    mCapacidade = 4;
}

SeqSets::~SeqSets()
{
    cout << "\n";
    while (not SeqSetVazia())
    {
        DeletarGrupo();
        cout << "\n";
    }
}

//funçao para destrutor
void SeqSets::DeletarGrupo()
{
    if (SeqSetVazia())
    {
        cout << "\n[ERRO] NÃO EXISTE NENHUM GRUPO!\n";
    }
    else
    {
        if (SeqSetUsandoVazia())
        {
            if (mPtProxGrupoVazio == NULL)
            {
                cout << "\n[ERRO] NÃO EXISTE NENHUM GRUPO!\n";
            }
            else
            {
                cout << "GRUPO " << mPtProxGrupoVazio->RetornaGrupoID() << " DELETADO!";
                delete mPtProxGrupoVazio;
                mTam--;
            }
        }
        else
        {
            Grupos *mPtDeletar;
            mPtDeletar = mPtFim;
            cout << "GRUPO " << mPtDeletar->RetornaGrupoID() << " DELETADO!";
            mPtFim = mPtDeletar->RetornaAnterior();
            delete mPtDeletar;
            mTam--;
            mUsando--;
        }
    }
}

//recebe dado esqcrito pelo usuario
void SeqSets::InsereDado()
{
    cout << "Digite o dado para insercao: ";
    pacote dado;
    cin >> dado.modelo;
    InsereDadoPorParametro(dado);
}

void SeqSets::InsereDadoPorParametro(pacote dado)
{
    Grupos *Inseri;
    Inseri = BuscaGruposInsercao(dado);
    Inseri->InsereGrupo(dado);
}

//pesquisa em qual grupo deve ser inserido o dado
Grupos *SeqSets::BuscaGruposInsercao(pacote dado)
{
    Grupos *Inseri;
    Grupos *mPtGrupo;
    mPtGrupo = mPtInicio;
    unsigned TamanhoIntervaloSeparacao;
    pacote DadoMeio;
    pacote elemento;
    while (mPtGrupo != NULL)
    {
        if (mPtGrupo->GrupoVazio())
        {
            return mPtGrupo;
        }
        else if (mPtGrupo->GrupoCheio())
        {
            //verificação se os elementos com id modelo se repetem
            if (strcmp(dado.modelo, mPtGrupo->RetornaMenor().modelo) == 0 and strcmp(dado.modelo, mPtGrupo->RetornaMaior().modelo) == 0)
            {
                //faz comparaçoes entre os elementos com id posicao
                if (dado.posicao > mPtGrupo->RetornaMenor().posicao)
                {
                    if (dado.posicao < mPtGrupo->RetornaMaior().posicao)
                    {

                        DadoMeio = mPtGrupo->RetornaMeio();
                        CriarGrupoProx(mPtGrupo);
                        TamanhoIntervaloSeparacao = mPtGrupo->RetornaTamanho() - mPtGrupo->RetornaPosicaoMeio();

                        Inseri = mPtGrupo->RetornaProximo();

                        for (unsigned i = 0; i < TamanhoIntervaloSeparacao; i++)
                        {
                            elemento = mPtGrupo->RetornaMaior();
                            mPtGrupo->RetiraFim();
                            Inseri->InsereGrupo(elemento);
                        }

                        if (dado.posicao < DadoMeio.posicao)
                        {
                            Inseri = mPtGrupo;
                        }

                        return Inseri;
                    }
                    else
                    {
                        mPtGrupo = mPtGrupo->RetornaProximo();
                    }
                }
                else
                {
                    //Se o dado for menor que o menor do grupo
                    CriarGrupoAnte(mPtGrupo);
                    return mPtGrupo->RetornaAnterior();
                }
            }
            else
            {
                //comparaçoes entre os elementos com id modelo
                if (strcmp(dado.modelo, mPtGrupo->RetornaMenor().modelo) == 1)
                {
                    if (strcmp(dado.modelo, mPtGrupo->RetornaMaior().modelo) == -1)
                    {

                        DadoMeio = mPtGrupo->RetornaMeio();
                        CriarGrupoProx(mPtGrupo);
                        TamanhoIntervaloSeparacao = mPtGrupo->RetornaTamanho() - mPtGrupo->RetornaPosicaoMeio();

                        Inseri = mPtGrupo->RetornaProximo();

                        for (unsigned i = 0; i < TamanhoIntervaloSeparacao; i++)
                        {
                            elemento = mPtGrupo->RetornaMaior();
                            mPtGrupo->RetiraFim();
                            Inseri->InsereGrupo(elemento);
                        }

                        if (dado.modelo < DadoMeio.modelo)
                        {
                            Inseri = mPtGrupo;
                        }

                        return Inseri;
                    }
                    else
                    {
                        mPtGrupo = mPtGrupo->RetornaProximo();
                    }
                }
                else
                {
                    //Se o dado for menor que o menor do grupo
                    CriarGrupoAnte(mPtGrupo);
                    return mPtGrupo->RetornaAnterior();
                }
            }
        }
        else
        {
            if (strcmp(dado.modelo, mPtGrupo->RetornaMenor().modelo) == 0 and strcmp(dado.modelo, mPtGrupo->RetornaMaior().modelo) == 0)
            {
                if (dado.posicao > mPtGrupo->RetornaMenor().posicao)
                {
                    if (dado.posicao < mPtGrupo->RetornaMaior().posicao)
                    {
                        return mPtGrupo;
                    }
                    else
                    {
                        if (mPtGrupo->RetornaProximo() != NULL)
                        {
                            mPtGrupo = mPtGrupo->RetornaProximo();

                            if (dado.posicao > mPtGrupo->RetornaMenor().posicao)
                            {
                                return mPtGrupo->RetornaAnterior();
                            }
                        }
                        else
                        {
                            return mPtGrupo;
                        }
                    }
                }
                else
                {
                    return mPtGrupo;
                }
            }
            else
            {
                if (strcmp(dado.modelo, mPtGrupo->RetornaMenor().modelo) == 1)
                {
                    if (strcmp(dado.modelo, mPtGrupo->RetornaMaior().modelo) == -1)
                    {
                        return mPtGrupo;
                    }
                    else
                    {
                        if (mPtGrupo->RetornaProximo() != NULL)
                        {
                            mPtGrupo = mPtGrupo->RetornaProximo();

                            if (strcmp(dado.modelo, mPtGrupo->RetornaMenor().modelo) == 1)
                            {
                                return mPtGrupo->RetornaAnterior();
                            }
                        }
                        else
                        {
                            return mPtGrupo;
                        }
                    }
                }
                else
                {
                    return mPtGrupo;
                }
            }
        }
    }
    CriarGrupo();
    return mPtFim;
}

//Criador de grupos se necessário
void SeqSets::CriarGrupo()
{
    if (SeqSetVazia())
    {
        Grupos *novo;
        novo = new Grupos(mCapacidade, mGrupo);
        mPtInicio = novo;
        mPtFim = mPtInicio;
        mTam++;
    }
    else if (mPtProxGrupoVazio != NULL)
    {
        mPtProxGrupoVazio->RecebeAnterior(mPtFim);
        mPtFim->RecebeProximo(mPtProxGrupoVazio);
        mPtFim = mPtProxGrupoVazio;
    }
    else
    {
        Grupos *novo;
        mGrupo++;
        novo = new Grupos(mCapacidade, mGrupo);
        novo->RecebeAnterior(mPtFim);
        mPtFim->RecebeProximo(novo);
        mPtFim = novo;
        mTam++;
    }
    mUsando++;
}
//cria grupo com que aceita valores maiores do que ja existe
void SeqSets::CriarGrupoProx(Grupos *mPtAnterior)
{
    Grupos *novo;

    if (mPtProxGrupoVazio == NULL)
    {
        mGrupo++;
        novo = new Grupos(mCapacidade, mGrupo);
        mTam++;
    }
    else
    {
        novo = mPtProxGrupoVazio;
    }
    Grupos *mPtProximo;
    mPtProximo = mPtAnterior->RetornaProximo();
    if (mPtProximo != NULL)
    {
        mPtProximo->RecebeAnterior(novo);
    }
    else
    {
        mPtFim = novo;
    }
    mPtAnterior->RecebeProximo(novo);
    novo->RecebeAnterior(mPtAnterior);
    novo->RecebeProximo(mPtProximo);
    mUsando++;
}
//cria grupo com que aceita valores menores do que ja existe
void SeqSets::CriarGrupoAnte(Grupos *mPtProximo)
{
    Grupos *novo;

    if (mPtProxGrupoVazio == NULL)
    {
        mGrupo++;
        novo = new Grupos(mCapacidade, mGrupo);
        mTam++;
    }
    else
    {
        novo = mPtProxGrupoVazio;
    }
    Grupos *mPtAnterior;
    mPtAnterior = mPtProximo->RetornaAnterior();
    if (mPtAnterior != NULL)
    {
        mPtAnterior->RecebeProximo(novo);
    }
    else
    {
        mPtInicio = novo;
    }
    mPtProximo->RecebeAnterior(novo);
    novo->RecebeAnterior(mPtAnterior);
    novo->RecebeProximo(mPtProximo);

    mUsando++;
}

//Mostra as informaçoes dos grupos
void SeqSets::Imprimir(){
    Grupos *mPtImprimir;
    mPtImprimir = mPtInicio;
    unsigned ProximoGrupo;
    if (mPtProxGrupoVazio == NULL)
    {
        ProximoGrupo = mGrupo + 1;
    }
    else
    {
        ProximoGrupo = mPtProxGrupoVazio->RetornaGrupoID();
    }

    cout << "\n------=========== SeqSet ===========------\n";

    cout << "Tamanho: " << mTam << "\nUsando: " << mUsando;
    cout << "\nProximo: " << ProximoGrupo << endl;
    while (mPtImprimir != NULL)
    {
        mPtImprimir->ImprimeGrupo();
        mPtImprimir = mPtImprimir->RetornaProximo();
    }
}
