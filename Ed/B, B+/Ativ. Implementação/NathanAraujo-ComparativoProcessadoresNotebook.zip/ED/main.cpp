/* 
  Trabalho de Estrutura de Dados 
  Copyright 2021 by Igor Freire de Morais, Nathan Araújo Silva, Mateus Peternelli
  É responsável por inserir o que ta no arquivo captura_pacotes_dos.csv no sequenceSet, e imprimir eles na tela.
*/



#include <iostream>
#include <cstring>
#include <fstream>
#include "sequenceSet.h"


int main(){
    std::ifstream arquivo_csv("captura_pacotes_dos.csv");
    if (not(arquivo_csv)) {
		return EXIT_FAILURE;
    }
	
    string linha;
    getline(arquivo_csv,linha); // descarta primeira linha do arquivo

    string campo; // variável para obter um campo de cada linha lida
    string delimitador = "\",\""; // delimitador entre os campos
    unsigned posFimCampo; // posição final do campo

    SeqSets SequenceSet;
    pacote umPacote;
    	
	while(getline(arquivo_csv,linha)) {
        campo = linha.erase(0,1); // remove primeiro caracter da linha (")
		//if para escrever em um arquivo somente o intervalo de origens que estamos procurando
		if (umPacote.posicao >= 1 and umPacote.posicao <= 100){
			//cout para testar se está pegando no indíce correto
			cout<<"Posicao: " << umPacote.posicao << endl;
			cout<<"Modelo: " << umPacote.modelo << endl;
            cout<<"Cache: " << umPacote.cache << endl;
            cout<<"Tdp: " << umPacote.tdp << endl;
			//entrando no sequenceSet
			SequenceSet.InsereDadoPorParametro(umPacote);
		}
		
		// obtendo primeiro campo, um inteiro - No.
        posFimCampo = linha.find(delimitador);
        campo = linha.substr(0, posFimCampo);
        linha.erase(0, posFimCampo + delimitador.length());
        umPacote.posicao = stoul2(campo);


		// obtendo terceiro campo, um texto - Source
        posFimCampo = linha.find(delimitador);
        campo = linha.substr(0, posFimCampo);
        linha.erase(0, posFimCampo + delimitador.length());
        strcpy(umPacote.modelo, campo.c_str());//destino: umPacote.origem    /   origem: campo.c_str()
        
        // obtendo quarto campo, um texto - Destination
        posFimCampo = linha.find(delimitador);
        campo = linha.substr(0, posFimCampo);
        linha.erase(0, posFimCampo + delimitador.length());
        strcpy(umPacote.cache, campo.c_str());

        posFimCampo = linha.find(delimitador);
        campo = linha.substr(0, posFimCampo);
        linha.erase(0, posFimCampo + delimitador.length());
        umPacote.tdp = stoul2(campo);
        
    }    
    
    return 0;   
    
}
